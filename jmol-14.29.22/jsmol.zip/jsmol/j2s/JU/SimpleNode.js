Clazz.declarePackage ("JU");
Clazz.declareInterface (JU, "SimpleNode");
